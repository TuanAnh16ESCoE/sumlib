from setuptools import setup

setup(
    name='suumfunction',
    version='0.1',
    url='https://github.com/TuanAnh16ESCoE/sumlib.git',
    license='',
    author='Andrew',
    author_email='',
    description='just example sum of 2 number',
    packages=[''],
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
