# Test sum package

Just a simple sum project
