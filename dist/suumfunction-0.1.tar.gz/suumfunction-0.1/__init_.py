# __init__.py
name = 'test_sum'